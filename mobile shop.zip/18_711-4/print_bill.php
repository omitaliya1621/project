<?php
//for without password not page direct open
session_start();
if(isset($_SESSION['m_a'])=="")
{
	header("location:index.php?msg4=stopp");
	exit(0);
}
//end password without
require_once("connect.php");
$a=$_REQUEST['u'];
$q=mysqli_query($cc,"select * from invoice_tbl where bid=$a")or die ("QF");
$data=mysqli_fetch_array($q);

?>
<!DOCTYPE html>
<head>
<title>title here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<script language="javascript" type="text/javascript">
function print_page()
{
	var DocumentContainer = document.getElementById("reciept_detail");
	var WindowObject = window.open('', "PrintWindow", "width=1024,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	
	WindowObject.document.writeln(DocumentContainer.innerHTML);
	WindowObject.document.close();
	WindowObject.focus();
	WindowObject.print();
	WindowObject.close();
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php require_once("header.php"); ?>
<!--header end-->
<!--sidebar start-->
<?php require_once("sidebar.php"); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		                <!-- market-------------------------------------------------------- -->	
		<!-- //market-->
		<div class="row">
			<div class="panel-body">
				<div class="col-md-12 w3ls-graph">
					<!--agileinfo-grap-->
						<div class="agileinfo-grap">
							<div class="agileits-box">
								<header class="agileits-box-header clearfix">
								
								
									<h3>Print Bill</h3>
									
									
									
								</header>
							<!--	//chartcode---------------------------------------------------------- -->
							
							
							
							<form id="form1" name="form1" method="post" action="">
	<div id="reciept_detail" class="reciept_detail" style="height:2000px">
	  <table width="50%" height="50%"  align="center"  class="table table-striped b-t b-light table-responsive>
        <tr>
          <td colspan="3">
	    <div align="center" >Selling Bill
	      <div align="right">
              <div style="width:50px; cursor:pointer;" align="center" class="button" onClick="return print_page();"><img src="imglogo/printdoc2.png" width="40" height="35" /></div>
	        </div>
	      </div>
	    <tr>
          <td colspan="3" align="center"><b>
            <h2>*__Sitaram Electronics &amp; Assesory Pvt__*</h2>
          </b></td>
	      </tr>
        <tr>
          <td colspan="3" align="right"><p>502, Waghavadi Road,<h3 align="Left">Bill Date:</h3>
		  Bhavnagar,364002</p></td>
		  
        </tr>
        <tr>
          <td colspan="2"><u>Bill no :<b><?php echo $data['bill_no'];?></b> </u> </td>
          <td width="40%"><div align="right"><u>Bill date :<?php echo $data['bill_date'];?> </u> </div></td>
        </tr>
        <tr>
          <td colspan="2">Costomer name :</td>
          <td><?php echo $data['customer_name'];?></td>
        </tr>
        <tr>
          <td colspan="2">Adress:</td>
          <td><?php echo $data['address'];?></td>
        </tr>
        <tr>
          <td colspan="2">Costomer Mobile No:</td>
          <td><?php echo $data['mobile'];?></td>
        </tr>
        <tr>
          <td colspan="2">Type Of Item(catagory):</td>
          <td><?php echo $data['cat_name'];?></td>
        </tr>
        <tr>
          <td colspan="2">Compny:</td>
          <td><?php echo $data['company_name'];?></td>
        </tr>
        <tr>
          <td colspan="2">Serese:</td>
          <td><?php echo $data['seriese'];?></td>
        </tr>
        <tr>
          <td colspan="2">Prise Of One Item:</td>
          <td><?php echo $data['selling_price'];?></td>
        </tr>
        <tr>
          <td colspan="2">Selling Quntity:</td>
          <td><?php echo $data['s_quantity'];?></td>
        </tr>
        <tr>
          <td colspan="2">Discount(%):</td>
          <td><?php echo $data['discount'];?>%</td>
        </tr>
        <tr>
          <td colspan="2">CGST(%):</td>
          <td><?php echo $data['cgst'];?>%</td>
        </tr>
        <tr>
          <td colspan="2">SGST(%):</td>
          <td><?php echo $data['sgst'];?>%</td>
        </tr>
        <tr>
          <td colspan="2">Total Amount:</td>
          <td><h3><?php echo $data['total_amount'];?>/--Rs.</h3></td>
        </tr>
     <!--   <tr>
          <td colspan="2">Total Amount in Words: </td>
          <td><h3>
            <?php 
		  $num=$data['total_amount'];
		 echo ucwords(numberTowords("$num"))."only"; 
		 
function numberTowords($num)
{ 
$ones = array( 
1 => "one", 
2 => "two", 
3 => "three", 
4 => "four", 
5 => "five", 
6 => "six", 
7 => "seven", 
8 => "eight", 
9 => "nine", 
10 => "ten", 
11 => "eleven", 
12 => "twelve", 
13 => "thirteen", 
14 => "fourteen", 
15 => "fifteen", 
16 => "sixteen", 
17 => "seventeen", 
18 => "eighteen", 
19 => "nineteen" 
); 
$tens = array( 
2 => "twenty", 
3 => "thirty", 
4 => "forty", 
5 => "fifty", 
6 => "sixty", 
7 => "seventy", 
8 => "eighty", 
9 => "ninety" 
); 
$hundreds = array( 
"hundred", 
"thousand", 
"million", 
"billion", 
"trillion", 
"quadrillion" 
); //limit t quadrillion 
$num = number_format($num,2,".",","); 
$num_arr = explode(".",$num); 
$wholenum = $num_arr[0]; 
$decnum = $num_arr[1]; 
$whole_arr = array_reverse(explode(",",$wholenum)); 
krsort($whole_arr); 
$rettxt = ""; 
foreach($whole_arr as $key => $i){ 
if($i < 20){ 
$rettxt .= $ones[$i]; 
}elseif($i < 100){ 
$rettxt .= $tens[substr($i,0,1)]; 
$rettxt .= " ".$ones[substr($i,1,1)]; 
}else{ 
$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
$rettxt .= " ".$tens[substr($i,1,1)]; 
$rettxt .= " ".$ones[substr($i,2,1)]; 
} 
if($key > 0){ 
$rettxt .= " ".$hundreds[$key]." "; 
} 
} 
if($decnum > 0){ 
$rettxt .= " and "; 
if($decnum < 20){ 
$rettxt .= $ones[$decnum]; 
}elseif($decnum < 100){ 
$rettxt .= $tens[substr($decnum,0,1)]; 
$rettxt .= " ".$ones[substr($decnum,1,1)]; 
} 
} 
return $rettxt; 
} 

?>
          </h3></td>
        </tr> -->
        <tr>
          <td colspan="2">Payment Method:</td>
          <td><?php echo $data['peymetho'];?></td>
        </tr>
        <tr>
          <td colspan="2">Paid Amount:</td>
          <td><?php echo $data['paidamt'];?>/--Rs.</td>
        </tr>
        <tr>
          <td colspan="2">Remaining Amount:</td>
          <td><?php echo $data['remamt'];?>/--Rs.</td>
        </tr>
        <tr>
          <td colspan="2"><div align="center"><b><u>Thanks...</u></b></div></td>
          <td><div align="right">Sing__________</div></td>
        </tr>
      </table>
	  </div>
       
							</form>
							
							
							
							
								
							</div>
						</div>
	<!--//agileinfo-grap-->

				</div>
			</div>
		</div>
		<div class="agil-info-calendar">
		<!-- calendar -->
		
		<!-- //calendar -->
		<!-- //notification------------------------------------------------------- -->
				<!--notification end-->
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
			<!-- tasks -->
			<!-- //reportdailymonthyear------------------------------------------------------------------- -->
		<!-- //tasks -->
	<!--	//chartok----------------------------------------------- -->
 <!-- footer -->
		<?php require_once("footer.php"); ?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->	
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
