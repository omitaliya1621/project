<?php
//for without password not page direct open
session_start();
if(isset($_SESSION['m_a'])=="")
{
	header("location:index.php?msg4=stopp");
	exit(0);
}
//end password without
require_once("connect.php");

$a=$_REQUEST['c'];
$q=mysqli_query($cc,"select selling_price,company_name,seriese,cat_name from product_tbl where pid=$a")or die("qf1");
$data=mysqli_fetch_array($q);
$com_name=$data['company_name'];
$se_name=$data['seriese'];
//bill number generate
$q1=mysqli_query($cc,"select max(bill_no) from invoice_tbl")or die("qf bill nomber auto");
$data1=mysqli_fetch_array($q1);
if($data1[0]=="")
{
	$bno=101;
}
else
{
	$bno=$data1[0]+1;
}	
extract($_POST);
//check stock coppy
$qw=mysqli_query($cc,"select s_quantity from stock_tbl where company_name='$com_name' and seriese='$se_name'")or die("Qf stock check");
$dataw=mysqli_fetch_array($qw);
$stock_qty=$dataw['s_quantity'];
if(isset($_REQUEST['Submit']))
{
//paste

if($s_qty>$stock_qty)
{
	header("location:create_invoice.php?msg=nostock&c=$a");
}
else
{
//stock update
$nstock=$stock_qty-$s_qty;
mysqli_query($cc,"update stock_tbl set s_quantity='$nstock' where company_name='$p_name' and seriese='$se'")or die("qf stock update");

//insert invoise tbl deteils
$nadd=nl2br($add);
mysqli_query($cc,"insert into invoice_tbl(pid,cat_name,company_name,seriese,selling_price,s_quantity,discount,cgst,sgst,total_amount,paidamt,remamt,peymetho,customer_name,mobile,address,bill_date,bill_no)values('$a','$cnm','$p_name','$se','$s_pri','$s_qty','$dis','$cg','$sg','$t_amt','$pa','$ra','$pm','$nm','$mob','$nadd','$bd','$bn')")or die("qf2"); 
header("location:view_invoice.php");
}

}	

 
?>

<!DOCTYPE html>
<head>
<link rel="stylesheet" href="button.css">
<title>title here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<!-- link calendar resources -->
	<link rel="stylesheet" type="text/css" href="tcal.css" />
	<script type="text/javascript" src="tcal.js"></script> 
<!-- end calender -->
</head>
<body>
<section id="container">
<!--header start-->
<?php require_once("header.php"); ?>
<!--header end-->
<!--sidebar start-->
<?php require_once("sidebar.php"); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		                <!-- market-------------------------------------------------------- -->	
		<!-- //market-->
		<div class="row">
			<div class="panel-body">
				<div class="col-md-12 w3ls-graph">
					<!--agileinfo-grap-->
						<div class="agileinfo-grap">
							<div class="agileits-box">
								<header class="agileits-box-header clearfix">
									<h3>Create Invoice</h3>
									
								</header>
							<!--	//chartcode---------------------------------------------------------- -->
								
								<form id="form1" name="form1" method="post" action="" onSubmit="return f1();">
      <table  border="0" align="center" class="table table-striped b-t b-light table-responsive" >
      
		  <tr>
          <td>Type of Item</td>
          <td>:</td>
          <td><input name="cnm" type="text" id="cnm" value="<?php echo $data['cat_name']; ?>" readonly="" /></td>
        </tr>
        <tr>
          <td>Compny Name </td>
          <td>:</td>
          <td><input name="p_name" type="text" id="p_name" value="<?php echo $data['company_name']; ?>" readonly="" /></td>
        </tr>
        <tr>
          <td>Serese Name </td>
          <td>:</td>
          <td><input name="se" type="text" id="se" readonly="" value=<?php echo $data['seriese']; ?> /></td>
        </tr>
        <tr>
          <td>Selling Price</td>
          <td>:</td>
          <td><input name="s_pri" type="text" id="s_pri" autofocus="autofocus" placeholder="Enter Selling Price" onKeyPress="return (event.charCode > 47 && event.charCode < 58)" value="<?php echo $data['selling_price']; ?>" /></td>
        </tr>
        <tr>
          <td>Selling Qty </td>
          <td>:</td>
          <td><input name="s_qty" type="text" id="s_qty"  placeholder="Enter Selling Quntity" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/>
          &nbsp; Present Stock=<?php echo $stock_qty; ?></td>
        </tr>
        <tr>
          <td>Descount(%)</td>
          <td>:</td>
          <td><input name="dis" type="text" id="dis"  placeholder="Enter Descount" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>CGST(%)</td>
          <td>:</td>
          <td><input name="cg" type="text" id="cg" placeholder="Enter CGST" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>SGST(%)</td>
          <td>:</td>
          <td><input name="sg" type="text" id="sg"  placeholder="Enter SGST" onBlur="return f2();" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>Total Amount</td>
          <td>:</td>
          <td><input name="t_amt" type="text" id="t_amt" size="25"  placeholder="Show Total Amount Automaticaly" readonly="readonly" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)" /></td>
        </tr>
        <tr>
          <td>Paid Amount </td>
          <td>:</td>
          <td><input name="pa" type="text" id="pa" onBlur="return f3();" placeholder="Paid Amount" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>Remaining Amount </td>
          <td>:</td>
          <td><input name="ra" type="text" id="ra" size="29" placeholder="Show Remaining Amount Automaticaly" readonly="readonly" onKeyPress="return (event.charCode > 47 && event.charCode < 58)" /></td>
        </tr>
        <tr>
          <td>Pay Method </td>
          <td>:</td>
          <td><select name="pm" id="pm">
            <option value="Select Method" selected="selected">Select Method</option>
            <option value="Cash">Cash</option>
            <option value="Atm">Atm</option>
            <option value="Online">Online</option>
			<option value="Upi">Upi</option>
            <option value="-">Other</option>
          </select>          </td>
        </tr>
        <tr>
          <td>Customer Name </td>
          <td>:</td>
          <td><input name="nm" type="text" id="nm" placeholder="Enter Customer Name" onKeyPress="return (event.charCode > 64 && 
	event.charCode < 91) || (event.charCode > 96 && event.charCode < 123 || event.charCode==32)"/></td>
        </tr>
        <tr>
          <td>Mobile No </td>
          <td>:</td>
          <td><input name="mob" type="text" id="mob"  placeholder="Enter Customer Mobile No" maxlength="10" pattern="[6-9]{1}[0-9]{9}" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>Cutomer Address </td>
          <td>:</td>
          <td><textarea name="add" id="add" placeholder="Enter Customer Address"></textarea></td>
        </tr>
        <tr>
          <td>Bill Date </td>
          <td>:</td>
          <td><div><input type="text" name="bd" id="bd" class="tcal" value="" /></div>
</td>
        </tr>
        <tr>
          <td>Bill No </td>
          <td>:</td>
          <td><input name="bn" type="text" id="bn" placeholder="Auto Generat Bill Nomber" value="<?php echo $bno; ?>"   onKeyPress="return (event.charCode > 47 && event.charCode < 58)" /></td>
        </tr>
        <tr>
          <td><div align="center">
            
			<button class="button" type="reset" name="Reset" value="Reset">Reset
  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
          </div></td>
          <td>&nbsp;</td>
          <td><div align="center">
            <button class="button" type="submit" name="Submit" value="Submit" onClick="return f1();">Submit
  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
          </div></td>
        </tr>
      </table>
    </form>
							</div>
						</div>
	<!--//agileinfo-grap-->

				</div>
			</div>
		</div>
		<div class="agil-info-calendar">
		<!-- calendar -->
		
		<!-- //calendar -->
		<!-- //notification------------------------------------------------------- -->
				<!--notification end-->
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
			<!-- tasks -->
			<!-- //reportdailymonthyear------------------------------------------------------------------- -->
		<!-- //tasks -->
	<!--	//chartok----------------------------------------------- -->
 <!-- footer -->
		<?php require_once("footer.php"); ?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->	
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
<script>

function f1()
{
	if(form1.s_pri.value=="")
	{	
		alert("Please Enter Selling Prise..");
		form1.s_pri.focus();
		return false;
	}	
	else if(form1.s_qty.value=="")
	{	
		alert("Please Enter Selling Qyentety..");
		form1.s_qty.focus();
		return false;
	}	
	else if(form1.dis.value=="")
	{	
		alert("Please Enter Descout..");
		form1.dis.focus();
		return false;
	}	
	else if(form1.cg.value=="")
	{	
		alert("Please Enter CGST..");
		form1.cg.focus();
		return false;
	}	
	else if(form1.sg.value=="")
	{	
		alert("Please Enter SGST..");
		form1.sg.focus();
		return false;
	}	
	else if(form1.t_amt.value=="")
	{	
		alert("Please Enter Total Amount..");
		form1.t_amt.focus();
		return false;
	}	
	else if(form1.pa.value=="")
	{	
		alert("Please Enter Paid Amount..");
		form1.pa.focus();
		return false;
	}	
	else if(form1.ra.value=="")
	{	
		alert("Please Enter Remaining Amount..");
		form1.ra.focus();
		return false;
	}	else if(form1.pm.value=="Select Method")
	{	
		alert("Please Select Pay Method..");
		form1.pm.focus();
		return false;
	}	
	else if(form1.nm.value=="")
	{	
		alert("Please Enter Customer Name..");
		form1.nm.focus();
		return false;
	}	
	else if(form1.mob.value=="")
	{	
		alert("Please Enter Mobile Nomber..");
		form1.mob.focus();
		return false;
	}	
	else if(form1.add.value=="")
	{	
		alert("Please Enter Customer Address..");
		form1.add.focus();
		return false;
	}
	else if(form1.bd.value=="")
	{	
		alert("Please Enter Bill Date..");
		form1.bd.focus();
		return false;
	}	
	else if(form1.bn.value=="")
	{	
		alert("Please Enter Bill Nomber..");
		form1.bn.focus();
		return false;
		
	}
			
}

function f2()
{

//string to int convert
	var sp=Number(form1.s_pri.value);
	var qt=Number(form1.s_qty.value);
	var de=Number(form1.dis.value);
	var cgs=Number(form1.cg.value);
	var sgs=Number(form1.sg.value);
//seling prise*qty count
	var nt=sp*qt;
//per(%) to Rup convert
	var der=(nt*de)/100;
	var cgsr=(nt*cgs)/100;
	var sgsr=(nt*sgs)/100;
//calculation
	var tm=(nt+cgsr+sgsr)-der;
	
	//for point after show two values
	t_amt.innerHTML= tm.toFixed(2);
	
//value pass
 form1.t_amt.value=tm;	
}
function f3()
{
	var tamt=Number(form1.t_amt.value);
	var pamt=Number(form1.pa.value);
	//remainig amount calculation
	var r_a=(tamt-pamt);
	//for point after show two values
	ra.innerHTML= r_a.toFixed(2);
	//value passing in shtml
	form1.ra.value=r_a;
}
</script>
<?php
if(isset($_REQUEST['msg'])=="nostock")
{
?>
<script>
alert("stock not Available !!!");

</script>
<?php 
}
?>



