<?php
//for without password not page direct open
session_start();
if(isset($_SESSION['m_a'])=="")
{
	header("location:index.php?msg4=stopp");
	exit(0);
}
//end password without
//connection file include
require_once("connect.php");

if(isset($_REQUEST['Addd']))
{
//Auto varieble create
extract($_POST);
//file consept
$fn1=$_FILES['pho1']['name'];
$fn2=$_FILES['pho2']['name'];
$fn3=$_FILES['pho3']['name'];
//file type
$ft1=$_FILES['pho1']['type'];
$ft2=$_FILES['pho2']['type'];
$ft3=$_FILES['pho3']['type'];
//file size
$fs1=$_FILES['pho1']['size'];
$fs2=$_FILES['pho2']['size'];
$fs3=$_FILES['pho3']['size'];

                                                          
	//check file type condition only image
	if($ft1!="image/bmp" && $ft1!="image/png" && $ft1!="image/jpeg" && $ft1!="image/jpg")
	{
		echo "Plese Image 1 is Valid format Upload";
		die;
	}
	
	if($ft2!="image/bmp" && $ft2!="image/png" && $ft2!="image/jpeg" && $ft2!="image/jpg" )
	{
		echo "Plese Image 2 is Valid format Upload";
		die;
	}
	
	if($ft3!="image/bmp" && $ft3!="image/png" && $ft3!="image/jpeg" && $ft3!="image/jpg")
	{
		echo "Plese Image 3 is Valid format Upload";
		die;
	}
	//condition file size maximum 2 mb upload(mb to byte convert)
	if($fs1>2101546)
	{
		echo "Upload File1 Min then 2 MB";
		die;
	}
	if($fs2>2101546)
	{
		echo "Upload File2 Min then 2 MB";
		die;
	}
	if($fs3>2101546)
	{
		echo "Upload File3 Min then 2 MB";
		die;
	}
	
	

		

$path="photo/";
$npath1=$path.$fn1;
$npath2=$path.$fn2;
$npath3=$path.$fn3;
move_uploaded_file($_FILES['pho1']['tmp_name'],$npath1);
move_uploaded_file($_FILES['pho2']['tmp_name'],$npath2);
move_uploaded_file($_FILES['pho3']['tmp_name'],$npath3);
//description Format
$wri=nl2br($discr);
//network array
$netw=implode(",",$net);
//for stock insert/update
$qs=mysqli_query($cc,"select * from stock_tbl where company_name='$cnm' and
seriese='$seri' ")or die("Qf stock check");
if(mysqli_num_rows($qs))
{
//stock update
$datas=mysqli_fetch_array($qs);
$old_qty=$datas['s_quantity'];
$new_qty=$old_qty+$p_qty;
mysqli_query($cc,"update stock_tbl set s_quantity='$new_qty' where company_name='$cnm' and
seriese='$seri' ")or  die("QF stock Update");
}
else
{
//insert stock
mysqli_query($cc,"insert into stock_tbl(company_name,seriese,s_quantity)values('$cnm','$seri','$p_qty')")or die ("Qf for stock insert");
}

//insert query product table
mysqli_query($cc,"insert into product_tbl(cat_name,company_name,imeino,network,color,seriese,ram,rom,camera,purchase_price,selling_price,p_quantity,battery,processer,battery_backup,weight,photo_1,photo_2,photo_3,description,screen_size,blootuth_virsion,garanty,warentey)values('$cat_namee','$cnm','$pnm','$netw','$color','$seri','$ram','$rom','$came','$p_price','$s_price','$p_qty','$bet','$pro','$b_bac','$weig','$fn1','$fn2','$fn3','$wri','$ssize','$blu','$gw','$wo')")or die("query fail");
//jump page
header("location:view_product.php");
}
	
?>
<link rel="stylesheet" href="button.css">
<!DOCTYPE html>
<head>
<title>title here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php require_once("header.php"); ?>
<!--header end-->
<!--sidebar start-->
<?php require_once("sidebar.php"); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		                <!-- market-------------------------------------------------------- -->	
		<!-- //market-->
		<div class="row">
			<div class="panel-body">
				<div class="col-md-12 w3ls-graph">
					<!--agileinfo-grap-->
						<div class="agileinfo-grap">
							<div class="agileits-box">
								<header class="agileits-box-header clearfix">
									<h3>Add New Product</h3>
								
								</header>
							<!--	//chartcode---------------------------------------------------------- -->
								
								<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
      <table width="50%" border="1" align="center"  class="table table-striped b-t b-light table-responsive">
      
        <tr>
          <td>Select categoy </td>
          <td>:</td>
          <td><select name="cat_namee" id="cat_namee" autofocus>
            <option value="Select catagory" selected="selected">Select category</option>
            <?php
		  $cq=mysqli_query($cc,"select cat_name from man_cat_tbl order by cat_name")or die("cat qf");
		  while($datac=mysqli_fetch_array($cq))
		  {
		  ?>
            <option value="<?php echo $datac['cat_name'];?>"><?php echo $datac['cat_name'];?></option>
            <?php
			}
			?>
          </select></td>
        </tr>
        <tr>
          <td>Company Name </td>
          <td>:</td>
          <td><label>
            <input name="cnm" type="text" id="cnm" placeholder="Company name" />
          </label></td>
        </tr>
        <tr>
          <td>IMEI No </td>
          <td>:</td>
          <td>
            <input name="pnm" type="text" id="pnm" placeholder="Enter IMEI NO.." />          </td>
        </tr>
        <tr>
          <td>Network</td>
          <td>:</td>
          <td><input name="net[]" type="checkbox" id="net[]" value="2G" />
            2G 
            
              <input name="net[]" type="checkbox" id="net[]" value="3G" />
              3G
              <input name="net[]" type="checkbox" id="net[]" value="4G" />
            4G
            
            <input name="net[]" type="checkbox" id="net[]" value="5G" />
            5G
            <input name="net[]" type="checkbox" id="net[]" value="-" checked="checked" />
            None</td>
        </tr>
        <tr>
          <td>Color</td>
          <td>:</td>
          <td><input name="color" type="radio" value="Red" />
            Red
            <input name="color" type="radio" value="Green" />
            Green
            <input name="color" type="radio" value="Blue" />
            Blue
            <input name="color" type="radio" value="-" checked="checked" />
            None </td>
        </tr>
        <tr>
          <td>series</td>
          <td>:</td>
          <td><label><input name="seri" type="text" id="seri" placeholder="Series Name" /></label></td>
        </tr>
        <tr>
          <td>Ram</td>
          <td>:</td>
          <td><input name="ram" type="radio" value="2Gb" />
            2Gb
            <input name="ram" type="radio" value="3Gb" />
            3Gb
            <input name="ram" type="radio" value="4Gb" />
            4Gb
            <input name="ram" type="radio" value="6Gb" />
            6Gb
            
            <input name="ram" type="radio" value="8Gb" />
            8Gb
            <input name="ram" type="radio" value="-" checked="checked" />
            None</td>
        </tr>
        <tr>
          <td>Rom</td>
          <td>:</td>
          <td><input name="rom" type="radio" value="16Gb" />
            16Gb
            <input name="rom" type="radio" value="32Gb" />
            32Gb
            <input name="rom" type="radio" value="128Gb" />
            128Gb
            <input name="rom" type="radio" value="256Gb" />
            256Gb
            <input name="rom" type="radio" value="-" checked="checked" />
            None</td>
        </tr>
        <tr>
          <td>Camera</td>
          <td>:</td>
          <td><input name="came" type="radio" value="48mph" />
            48mp 
              <input name="came" type="radio" value="64mph" />
            64mp
            <input name="came" type="radio" value="108mph" />
            108mp
            <input name="came" type="radio" value="-" checked="checked" />
            None</td>
        </tr>
        <tr>
          <td>Purchase Price </td>
          <td>:</td>
          <td><input name="p_price" type="text" id="p_price" placeholder="Purchase Price" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)"/></td>
        </tr>
        <tr>
          <td>Selling Price </td>
          <td>:</td>
          <td><input name="s_price" type="text" id="s_price" placeholder="selling Price" onBlur="return f2();" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)" />
            (Rs.)          </td>
        </tr>
        <tr>
          <td>Profit </td>
          <td>:</td>
          <td><input name="pip2" type="text" id="pip2" />
          (Rs.)            
            <input name="pip" type="text" id="pip" onBlur="return f3();" />
            (%) </td>
        </tr>
        <tr>
          <td>Purchase Quntity </td>
          <td>:</td>
          <td><input name="p_qty" type="text" id="p_qty" placeholder="Purchase Quntity" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58)" /></td>
        </tr>
        <tr>
          <td>Battery</td>
          <td>:</td>
          <td><p>
                <input name="bet" type="radio" value="4500mha" />
            4500mah
            <input name="bet" type="radio" value="5000mha" />
            5000mah
              <input name="bet" type="radio" value="6000mha" />
              6000mah
              <input name="bet" type="radio" value="-" checked="checked" />
              None</p>            </td>
        </tr>
        <tr>
          <td>Processor</td>
          <td>:</td>
          <td><input name="pro" type="text" id="pro" placeholder="Enter Processor Name" /></td>
        </tr>
        <tr>
          <td>Battery Backup </td>
          <td>:            </td>
          <td><select name="b_bac" id="b_bac">
            <option value="Select Battery Bacup" selected="selected">Select Battery Backup</option>
            <option value="1hour">1hour</option>
            <option value="2hour">2hour</option>
            <option value="3hour">3hour</option>
            <option value="5hour">5hour</option>
            <option value="6hour">6hour</option>
            <option value="-">None</option>
                              </select></td>
        </tr>
        <tr>
          <td>Weight</td>
          <td>:</td>
          <td><input name="weig" type="text" id="weig" placeholder="Enter Weight" /></td>
        </tr>
        <tr>
          <td>Photo 1 </td>
          <td>:</td>
          <td><input name="pho1" type="file" id="pho1" /></td>
        </tr>
        <tr>
          <td>Photo 2 </td>
          <td>:</td>
          <td><input name="pho2" type="file" id="pho2" /></td>
        </tr>
        <tr>
          <td>Photo 3 </td>
          <td>:</td>
          <td><input name="pho3" type="file" id="pho3" /></td>
        </tr>
        <tr>
          <td>Screen size </td>
          <td>:</td>
          <td><input name="ssize" type="text" id="ssize" placeholder="Enter Screen Size" /></td>
        </tr>
        <tr>
          <td>Bluetooth version </td>
          <td>:</td>
          <td><input name="blu" type="radio" value="2.0" />
            2.0
            <input name="blu" type="radio" value="3.0" />
            3.0
            <input name="blu" type="radio" value="6.0" />
            6.0
            <input name="blu" type="radio" value="-" checked="checked" />
            None</td>
        </tr>
        <tr>
          <td>Guarantee</td>
          <td>:</td>
          <td><input name="gw" type="text" id="gw" placeholder="Enter Guarantee"/></td>
        </tr>
        <tr>
          <td>Warranty</td>
          <td>:</td>
          <td><input name="wo" type="text" id="wo" placeholder="Enter Warranty" /></td>
        </tr>
        <tr>
          <td>Description</td>
          <td>:</td>
          <td><textarea name="discr" id="discr" placeholder="Enter Description"></textarea></td>
        </tr>
        <tr>
          <td><div align="center">
           
			<button class="button" type="reset" name="Reset" value="Reset">Reset
  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
          </div></td>
          <td>&nbsp;</td>
          <td><div align="center">
            
			<button  name="Addd"class="button"type="submit" id="Addd" value="Submit" onClick="return f1();">Submit
  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
				
          </div></td>
        </tr>
      </table>
        </form>
							</div>
						</div>
	<!--//agileinfo-grap-->

				</div>
			</div>
		</div>
		<div class="agil-info-calendar">
		<!-- calendar -->
		
		<!-- //calendar -->
		<!-- //notification------------------------------------------------------- -->
				<!--notification end-->
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
			<!-- tasks -->
			<!-- //reportdailymonthyear------------------------------------------------------------------- -->
		<!-- //tasks -->
	<!--	//chartok----------------------------------------------- -->
 <!-- footer -->
		<?php require_once("footer.php"); ?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->	
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
<script>
function f1()
{  
	
	if(form1.cat_namee.value=="Select catagory")
	{	
	alert("Please Select Your Catagory!!!");
	form1.cat_namee.focus();
	return false;
	}
	else if(form1.cnm.value=="")
	{
		alert("Plese Enter Compyname!!!");
		form1.cnm.focus();
		return false;
	}
	else if(form1.pnm.value=="")
	{
		alert("Plese Enter IMEI NO!!!");
		form1.pnm.focus();
		return false;
	}
	else if(form1.seri.value=="")
	{
		alert("Plese Enter serise Name!!!");
		form1.seri.focus();
		return false;
	}
	else if(form1.ram.value=="")
	{
		alert("Plese Enter Ram Name!!!");
		form1.ram.focus();
		return false;
	}
	else if(form1.rom.value=="")
	{
		alert("Plese Enter Rom Name!!!");
		form1.rom.focus();
		return false;
	}
	else if(form1.p_price.value=="")
	{
		alert("Plese Enter Purchas Prise!!!");
		form1.p_price.focus();
		return false;
	}
	else if(form1.s_price.value=="")
	{
		alert("Plese Enter Selling Price!!!");
		form1.s_price.focus();
		return false;
	}
	else if(form1.p_qty.value=="")
	{
		alert("Plese Enter Purchas Quntity!!!");
		form1.p_qty.focus();
		return false;
	}
	else if(form1.pro.value=="")
	{
		alert("Plese Enter Prossesor Name!!!");
		form1.pro.focus();
		return false;
	}
	else if(form1.b_bac.value=="Select Battery Bacup")
	{
		alert("Plese Select Batery Bacup!!!");
		form1.b_bac.focus();
		return false;
	}
	else if(form1.weig.value=="")
	{
		alert("Plese Enter Weight!!!");
		form1.weig.focus();
		return false;
	}
	else if(form1.pho1.value=="")
	{
		alert("Plese Upload Product Photo(1)!!!");
		form1.pho1.focus();
		return false;
	}
	else if(form1.pho2.value=="")
	{
		alert("Plese Upload Product Photo(2)!!!");
		form1.pho2.focus();
		return false;
	}
	else if(form1.pho3.value=="")
	{
		alert("Plese Upload Product Photo(3)!!!");
		form1.pho3.focus();
		return false;
	}
	else if(form1.ssize.value=="")
	{
		alert("Plese Enter Screen Size!!!");
		form1.ssize.focus();
		return false;
	}
	else if(form1.gw.value=="")
	{
		alert("Plese Enter Product Gwarenty!!!");
		form1.gw.focus();
		return false;
	}
	else if(form1.wo.value=="")
	{
		alert("Plese Enter Product Worenty!!!");
		form1.wo.focus();
		return false;
	}
	else if(form1.discr.value=="")
	{
		alert("Plese Enter Product Description!!!");
		form1.discr.focus();
		return false;
	}
	
}
function f2()
{	
	var p_pr = Number(form1.p_price.value);
	var s_pr= Number(form1.s_price.value);
	 
	if(p_pr>s_pr)
	{
		form1.s_price.value='';
		
		alert("Please enter Valid Seling Price")
		form1.p_price.focus();
		form1.pip.value='';
		form1.pip2.value='';
		return false;
	
	}
	//profit percentage convert
	var profit=(s_pr-p_pr);
	form1.pip2.value= profit;
	var prop=(profit*100)/p_pr;
	form1.pip.value= prop;
	//for point after show two values
	pip.innerHTML=prop.toFixed(2);	
}

function f3()
{
var pipo=Number(form1.pip.value);
var p_pr = Number(form1.p_price.value);
	var s_pr= Number(form1.s_price.value);
//s_price
//pip2
	var prop1=s_pr-p_pr;
	form1.pip2.value=prop1;
	var prop2=p_pr*pipo/100;
	var prop3=(p_pr+prop2);
	form1.s_price.value=prop3;
	//var prop1=(pipo*100)/p_pr;
	
}
</script>

