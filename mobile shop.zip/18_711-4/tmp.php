<?php
$a="ok";
$b=md5($a);
echo $b;die;
?>