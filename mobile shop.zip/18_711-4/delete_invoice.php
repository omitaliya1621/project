<?php
require_once("connect.php");
$ed=$_REQUEST['del'];
//select query invoice table
$q=mysqli_query($cc,"select s_quantity,company_name,seriese from  invoice_tbl where bid=$ed")or die("Select query fail");
$data=mysqli_fetch_array($q);
$o_sqty=$data['s_quantity'];
$ccnnmm=$data['company_name'];
$sseerr=$data['seriese'];
// select query stock tbl
$qs=mysqli_query($cc,"select s_quantity from stock_tbl where  company_name='$ccnnmm' and seriese='$sseerr'")or die("Qf stock check");
$datas=mysqli_fetch_array($qs);
$p_stock=$datas['s_quantity']; 

//calculation for stock plus
$nstock=$o_sqty+$p_stock;

//update stock tbl
mysqli_query($cc,"update stock_tbl set s_quantity='$nstock' where company_name='$ccnnmm' and seriese='$sseerr' ")or  die("QF stock Update");
//delete query
mysqli_query($cc,"delete from invoice_tbl where bid=$ed")or die("delete query fail invoice");
 header("location:view_invoice.php");

?>