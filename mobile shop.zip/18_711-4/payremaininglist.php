<?php
session_start();
?>
<!DOCTYPE html>
<head>
<title>title here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<!-- for print data -->
<script language="javascript" type="text/javascript">
function print_page()
{
	var DocumentContainer = document.getElementById("reciept_detail");
	var WindowObject = window.open('', "PrintWindow", "width=1024,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	
	WindowObject.document.writeln(DocumentContainer.innerHTML);
	WindowObject.document.close();
	WindowObject.focus();
	WindowObject.print();
	WindowObject.close();
}
</script>
<!-- for print data end -->
</head>
<body>
<section id="container">
<!--header start-->
<?php require_once("header.php"); ?>
<!--header end-->
<!--sidebar start-->
<?php require_once("sidebar.php"); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		                <!-- market-------------------------------------------------------- -->	
		<!-- //market-->
		<div class="row">
			<div class="panel-body">
				<div class="col-md-12 w3ls-graph">
					<!--agileinfo-grap-->
						<div class="agileinfo-grap">
							<div class="agileits-box">
								<header class="agileits-box-header clearfix">
								
								
									<h3>Remaining Payment List</h3>
									
									
									
								</header>
							<!--	//chartcode---------------------------------------------------------- -->
							
							
				<div id="reciept_detail" class="reciept_detail" style="height:500px">			
				<form id="form1" name="form1" method="post" action="">
      <table width="50%" border="1" align="center" class="table table-striped b-t b-light table-responsive">
	  <thead>
       <tr>
		
          <td >No</td>
          <td >Name</td>
          <td>Remaining Amount</td>
		  <td>Catagory</td>
		  <td>Compny</td>
		  <td>serice</td>
		  <td>price</td>
		  <td>paid Amount</td>
		  <td>mobileno</td>
		  <td>Billdate</td>
		     <td>Action </td>
		 
        </tr>	
		</thead>
		<?php
		require_once("connect.php");
		$no=1;
		$q1=mysqli_query($cc,"select * from invoice_tbl where remamt>0")or die("qf");
		while($data=mysqli_fetch_array($q1))
		{
		?>
        <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $data['customer_name'];?></td>
          <td><?php echo $data['remamt'];?></td>
		  <td><?php echo $data['cat_name'];?></td>
		  <td><?php echo $data['company_name'];?></td>
		  <td><?php echo $data['seriese'];?></td>
		  <td><?php echo $data['selling_price'];?></td>
		  <td><?php echo $data['paidamt'];?></td>
		  <td><?php echo $data['mobile'];?></td>
		<td><?php echo $data['bill_date'];?></td>
		 <td ><a href="more_invoice.php?r=<?php echo $data['bid'];?>"><img src="imglogo/readmore1.png" height="40" width="70" /></a></td>
		 


        </tr>
		<?php
		$no++;
		}
		?>
		<tr>
		<td colspan="11" align="center"><div style="width:50px; cursor:pointer;" align="center" class="button" onClick="return print_page();"><img src="imglogo/printdoc2.png" height="35" width="40" /></div><div align="right"><b>-Remainong Payment List&nbsp;&nbsp;Date=<?php echo date('d-M-Y'); ?> </b></div></td>
		</tr>
      </table>
        <div align="center"></div>
    </form>
	</div>
							
							
							
							
							
								
							</div>
						</div>
	<!--//agileinfo-grap-->

				</div>
			</div>
		</div>
		<div class="agil-info-calendar">
		<!-- calendar -->
		
		<!-- //calendar -->
		<!-- //notification------------------------------------------------------- -->
				<!--notification end-->
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
			<!-- tasks -->
			<!-- //reportdailymonthyear------------------------------------------------------------------- -->
		<!-- //tasks -->
	<!--	//chartok----------------------------------------------- -->
 <!-- footer -->
		<?php require_once("footer.php"); ?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->	
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
