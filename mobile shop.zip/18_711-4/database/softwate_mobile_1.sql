-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2024 at 12:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `softwate_mobile_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `aid` int(3) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `email` varchar(35) NOT NULL,
  `a_photo` varchar(100) NOT NULL,
  `loginid` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `lastdate` text NOT NULL,
  `lasttime` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`aid`, `name`, `mobile`, `email`, `a_photo`, `loginid`, `password`, `lastdate`, `lasttime`) VALUES
(1, 'OM ITALIY', '9999999998', 'om@gmail', 'icon48.png.jpg', 'Admin', '444bcb3a3fcf8389296c49467f27e1d6', '11-04-2024', '01:13:47pm');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_tbl`
--

CREATE TABLE `invoice_tbl` (
  `bid` int(3) NOT NULL,
  `pid` int(3) NOT NULL,
  `cat_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `seriese` varchar(30) NOT NULL,
  `selling_price` varchar(10) NOT NULL,
  `s_quantity` int(10) NOT NULL,
  `discount` varchar(5) NOT NULL,
  `cgst` varchar(5) NOT NULL,
  `sgst` varchar(5) NOT NULL,
  `total_amount` varchar(10) NOT NULL,
  `paidamt` varchar(4) NOT NULL,
  `remamt` varchar(4) NOT NULL,
  `peymetho` varchar(8) NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `address` text NOT NULL,
  `bill_date` date NOT NULL,
  `bill_no` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoice_tbl`
--

INSERT INTO `invoice_tbl` (`bid`, `pid`, `cat_name`, `company_name`, `seriese`, `selling_price`, `s_quantity`, `discount`, `cgst`, `sgst`, `total_amount`, `paidamt`, `remamt`, `peymetho`, `customer_name`, `mobile`, `address`, `bill_date`, `bill_no`) VALUES
(1, 1, 'MOBILE', 'apple ', 'pro', '60000', 1, '2', '5', '5', '64800', '6480', '0', 'Cash', 'om italiya', '9999999999', 'bhavnagar', '2024-04-11', 101);

-- --------------------------------------------------------

--
-- Table structure for table `man_cat_tbl`
--

CREATE TABLE `man_cat_tbl` (
  `mid` int(3) NOT NULL,
  `cat_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `man_cat_tbl`
--

INSERT INTO `man_cat_tbl` (`mid`, `cat_name`) VALUES
(1, 'MOBILE'),
(2, 'TV'),
(3, 'AC'),
(4, 'LAPTOP');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE `product_tbl` (
  `pid` int(3) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `imeino` varchar(20) NOT NULL,
  `network` varchar(15) NOT NULL,
  `color` char(12) NOT NULL,
  `seriese` varchar(8) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `rom` varchar(10) NOT NULL,
  `camera` varchar(15) NOT NULL,
  `purchase_price` varchar(10) NOT NULL,
  `selling_price` varchar(10) NOT NULL,
  `p_quantity` int(5) NOT NULL,
  `battery` varchar(10) NOT NULL,
  `processer` varchar(20) NOT NULL,
  `battery_backup` varchar(8) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `photo_1` varchar(100) NOT NULL,
  `photo_2` varchar(100) NOT NULL,
  `photo_3` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `screen_size` varchar(5) NOT NULL,
  `blootuth_virsion` varchar(5) NOT NULL,
  `garanty` text NOT NULL,
  `warentey` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`pid`, `cat_name`, `company_name`, `imeino`, `network`, `color`, `seriese`, `ram`, `rom`, `camera`, `purchase_price`, `selling_price`, `p_quantity`, `battery`, `processer`, `battery_backup`, `weight`, `photo_1`, `photo_2`, `photo_3`, `description`, `screen_size`, `blootuth_virsion`, `garanty`, `warentey`) VALUES
(1, 'MOBILE', 'apple ', '123456789', '2G,3G,4G,5G', '-', 'pro max', '-', '256Gb', '108mph', '50000', '60000', 10, '5000mha', 'snap dragon 8gen', '1hour', '250gr', 'a1.png', 'a2.jpg', 'a3.jpg', 'high performance, 4k video,', '4 in', '6.0', '6 month', '1 year'),
(2, 'MOBILE', 'samsung', '123456789', '2G,3G,4G,5G', 'Blue', 's', '8Gb', '256Gb', '108mph', '40000', '60000', 20, '6000mha', 'octa core', '3hour', '250 gram', 's1.jpg', 's2.jpg', 's3.jpg', 'best gaming mobile', '5 in', '6.0', '1 year', '2 year'),
(3, 'MOBILE', 'nothing', '321456987', '2G,3G,4G,5G', '-', 'nothing ', '6Gb', '128Gb', '64mph', '25000', '30000', 8, '4500mha', 'dimencity ', '5hour', '150 gram', 'n1.jpg', 'n2.jpg', 'n3.jpg', 'best   feature, best gaming', '4.5in', '6.0', '6 month', '1 year'),
(4, 'AC', 'lg', '--', '-', '-', '--', '-', '-', '-', '40000', '50000', 12, '-', '--', '-', '40 kg', 'l11.jpg', 'l2.jpg', 'l3.jpg', 'low electricity', '--', '-', '2 year', '5 year'),
(5, 'AC', 'tata', '--', '-', '-', '--', '-', '-', '-', '50000', '70000', 19, '-', '--', '-', '50 kg', 'b1.jpg', 'b2.jpg', 'b3.jpg', 'low electricity', '--', '-', '2 year', '5 year');

-- --------------------------------------------------------

--
-- Table structure for table `stock_tbl`
--

CREATE TABLE `stock_tbl` (
  `sid` int(3) NOT NULL,
  `company_name` varchar(20) NOT NULL,
  `seriese` varchar(10) NOT NULL,
  `s_quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stock_tbl`
--

INSERT INTO `stock_tbl` (`sid`, `company_name`, `seriese`, `s_quantity`) VALUES
(1, 'apple ', 'pro max', 10),
(2, 'samsung', 's', 20),
(3, 'nothing', 'nothing n1', 8),
(4, 'lg', '--', 12),
(5, 'tata', '--', 19);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `invoice_tbl`
--
ALTER TABLE `invoice_tbl`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `man_cat_tbl`
--
ALTER TABLE `man_cat_tbl`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `stock_tbl`
--
ALTER TABLE `stock_tbl`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `aid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoice_tbl`
--
ALTER TABLE `invoice_tbl`
  MODIFY `bid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `man_cat_tbl`
--
ALTER TABLE `man_cat_tbl`
  MODIFY `mid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product_tbl`
--
ALTER TABLE `product_tbl`
  MODIFY `pid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock_tbl`
--
ALTER TABLE `stock_tbl`
  MODIFY `sid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
