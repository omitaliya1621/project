<?php
$a=$_SESSION['m_a'];
require_once("connect.php");
$dataq=mysqli_query($cc,"select * from admin_tbl where aid=$a")or die("Qf");
$data_admin=mysqli_fetch_array($dataq);

?>
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
<a href="home.php" class="logo">
Admin
</a>
<div class="sidebar-toggle-box">
<div class="fa fa-bars"></div>
</div>
</div>
<!--logo end-->
<div class="nav notify-row" id="top_menu">
<!-- notification start -->

<!-- notification end -->
</div>
<div class="top-nav clearfix">
<!--search & user info start-->
<ul class="nav pull-right top-menu">
<li>Last Login <b>time</b> is &#8658 <b><?php echo $data_admin['lasttime'];?></b> </li>
<li>&</li>
<li>Last Login <b>Date</b> is &#8658 <b><?php echo $data_admin['lastdate'];?></b> </li>

 <?php require_once("search.php"); ?>
 
 
<!-- user login dropdown start-->
<li class="dropdown">
<a data-toggle="dropdown" class="dropdown-toggle" href="#">
<img alt="" src="admin_photo/<?php echo $data_admin['a_photo']; ?>"height="45" width="45" style="border-radius:20px;">
<span class="username"><?php echo $data_admin['name']; ?></span>
<b class="caret"></b>
</a>
<ul class="dropdown-menu extended logout">
<li><a href="profile.php"><i class=" fa fa-suitcase"></i>Profile</a></li>
<li><a href="change_pass.php"><i class="fa fa-cog"></i>Change Password</a></li>
<li><a href="logout.php"><i class="fa fa-key"></i> Logout</a></li>
</ul>
</li>
<!-- user login dropdown end -->

</ul>
<!--search & user info end-->
</div>

</header>