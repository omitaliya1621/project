<?php
require_once("connect.php");
$ed=$_REQUEST['del'];
$q1=mysqli_query($cc,"select company_name,seriese,photo_1,photo_2,photo_3  from product_tbl where pid=$ed")or die("qf1");
$data=mysqli_fetch_array($q1);
$ccnnmm=$data['company_name'];
$sseerr=$data['seriese'];

//delete product photo folder
$ofn1=$data['photo_1'];
$ofn2=$data['photo_2'];
$ofn3=$data['photo_3'];
$path="photo/";
$opath1=$path.$ofn1;
$opath2=$path.$ofn2;
$opath3=$path.$ofn3;
unlink($opath1);
unlink($opath2);
unlink($opath3);

// stock table entry delete
mysqli_query($cc,"delete from stock_tbl where company_name='$ccnnmm' and  seriese='$sseerr' ")or die("qf2");
//product table entry delete
mysqli_query($cc,"delete from product_tbl where pid=$ed")or die("qf3");
//page jump
header("location:view_product.php");

?>