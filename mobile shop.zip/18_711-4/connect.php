<?php
$cc=mysqli_connect("localhost","root","","softwate_mobile_1")or die("Connection Fail");
?>