<?php
session_start();
require_once("connect.php");
extract($_POST);
if(isset($_REQUEST['login']))
{
	
	extract($_POST);
	
	
	$p=md5($pwd);
$q=mysqli_query($cc,"select * from admin_tbl where  password='$p' and (mobile='$lid' or email='$lid' or loginid='$lid')")or die ("QF");
	if(mysqli_num_rows($q))
	{
		$data=mysqli_fetch_array($q);
		$_SESSION['m_a']=$data['aid'];
		
	header("location:home.php");
	}
	else
	{
		header("location:index.php?msg=wrong");
	}
	
}
?>
<!DOCTYPE html>
<head>
<title>Titale here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<!-- for password hide and show check box -->
<script>
function myFunction() {
  var x = document.getElementById("pwd");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<!-- for password hide and show check box end -->
</head>
<body>
<div class="log-w3">
<div class="w3layouts-main">
	<h2>Sign In Now</h2>
		<form action="" method="post" name="form1" id="form1">
			<input type="text" class="ggg" name="lid" placeholder="loginid/mobile/emailid" required="" autofocus>
			<input type="password" class="ggg" name="pwd" id="pwd" placeholder="PASSWORD" required="">
<input type="checkbox" name="checkbox" onClick="myFunction();" value="checkbox">
		
				<div class="clearfix"></div>
				<input type="submit" value="Sign In" name="login" onClick="return f1();">
		</form>
		
</div>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<script>
function f1()
{
   if(form1.lid.value=="")
   {
    alert("Enter Login id");
	form1.lid.focus();
	return false;
   }
   else if(form1.pwd.value=="")
   {
   	alert("Enter Password");
	form1.pwd.focus();
	return false;
   }
}
</script>

<?php if(isset($_REQUEST['msg'])=="wrong") { ?>
<script>
alert("Login ID or Password Incorrect");
</script>
<?php } ?>
<?php if(isset($_REQUEST['msg1'])=="logout") { ?>
<script>
alert("Logout Suucussfully...");
</script>
<?php } ?>
<?php if(isset($_REQUEST['msg2'])=="change") { ?>
<script>
alert("Password changed Sucsessfully Plese Login New Password!!!");
</script>
<?php } ?>
<?php if(isset($_REQUEST['msg4'])=="stopp") { ?>
<script>
alert("Plese Login To Access!!!");
</script>
<?php } ?>

