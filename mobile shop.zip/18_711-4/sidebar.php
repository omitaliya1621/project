<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="home.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashbord</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Main Category Management</span>
                    </a>
                    <ul class="sub">
						<li><a href="add_main_category.php">Add Main category</a></li>
						<li><a href="view_category.php">View Main category</a></li>
						
                    </ul>
                </li>
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-th"></i>
                        <span>Product Management</span>
                    </a>
                    <ul class="sub">
                        <li><a href="product_add.php">Add Product</a></li>
                        <li><a href="view_product.php">View Product</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-tasks"></i>
                        <span>Invoice</span>
                    </a>
                    <ul class="sub">
                        <li><a href="create_invoice_m.php">Create Invoice</a></li>
                        <li><a href="view_invoice.php">View Invoice</a></li>
						<li><a href="print_bill_m.php">Print Invoice</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-envelope"></i>
                        <span>Report</span>
                    </a>
                    <ul class="sub">
                        <li><a href="report.php">Today's selling </a></li>
                        <li><a href="reportfrom_to.php">From-To selling</a></li>
						<li><a href="payremaininglist.php">Paymet Remaining</a></li>
                    </ul>
                </li>
				  <li>
                    <a href="view_stock.php">
                        <i class="fa fa-user"></i>
                        <span>Stock View</span>
                    </a>
                </li>
                
                  <li>
                    <a href="logout.php">
                        <i class="fa fa-user"></i>
                        <span>Logout</span>
                    </a>
                </li>
              
               
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>