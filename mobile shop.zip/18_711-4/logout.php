<?php
session_start();
require_once("connect.php");
extract($_POST);

//for last login date and time show
 $aaii=$_SESSION['m_a'];
		//for current login date
	 $lld=date('d-m-Y');
	 //for current login time
	date_default_timezone_set("Asia/Calcutta");
	$llt= date("h:i:sa");
	
	//update query
	mysqli_query($cc,"update admin_tbl set lastdate='$lld' ,lasttime='$llt' where aid=$aaii ")or die("qf lll");
$_SESSION['m_a']='';
//for last login date and time show end

session_destroy();
if($_REQUEST['m']=="1")
{

header("location:index.php?msg2=change");
}
else
{
header("location:index.php?msg1=logout");
}
?>