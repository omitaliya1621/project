<?php
//for without password not page direct open
session_start();
if(isset($_SESSION['m_a'])=="")
{
	header("location:index.php?msg4=stopp");
	exit(0);
}
//end password without

require_once("connect.php");
$ed=$_REQUEST['edi'];
extract($_POST);

  
//select query invoice table
$q=mysqli_query($cc,"select * from invoice_tbl where bid=$ed")or die("Select query fail");
$data=mysqli_fetch_array($q);
$o_sqty=$data['s_quantity'];
$ccnnmm=$data['company_name'];
$sseerr=$data['seriese'];
//slect query stock table for stock management
$qs=mysqli_query($cc,"select * from stock_tbl where  company_name='$ccnnmm' and
seriese='$sseerr'")or die("Qf stock check");
$datas=mysqli_fetch_array($qs); 
$old_qty=$datas['s_quantity'];
$ppoqty=$old_qty+$o_sqty;

if(isset($_REQUEST['Submit']))
{


//stock check
if($s_qty>$ppoqty)
{
	header("location:edit_invoice.php?msg=nostock&edi=$ed");
}
else
{ //stock check end and php end } cous
//for address line
$nadd=nl2br($add);
//stock management
if($o_sqty>$s_qty)
	{	
	//stock update plus
$dif1=$o_sqty-$s_qty;
$new_qty1=$old_qty+$dif1;
mysqli_query($cc,"update stock_tbl set s_quantity='$new_qty1' where company_name='$ccnnmm' and seriese='$sseerr' ")or  die("QF stock Update");
   //for invois tbl update
mysqli_query($cc,"update invoice_tbl set cat_name='$cnm',company_name='$p_name',seriese='$se',selling_price='$s_pri',s_quantity='$s_qty',discount='$dis',cgst='$cg',sgst='$sg',total_amount='$t_amt',paidamt='$pa',remamt='$ra',peymetho='$pm',customer_name='$nm',mobile='$mob',address='$nadd',bill_date='$bd',bill_no='$bn' where bid=$ed ")or die("qf for update invoice ");
header("location:view_invoice.php");
    }
	else if($o_sqty<$s_qty)
	{	
	
	//stock update minus
	$dif2=$s_qty-$o_sqty;
	$new_qty=$old_qty-$dif2;
mysqli_query($cc,"update stock_tbl set s_quantity='$new_qty' where company_name='$ccnnmm' and seriese='$sseerr' ")or  die("QF stock Update");
   //for invois tbl update
mysqli_query($cc,"update invoice_tbl set cat_name='$cnm',company_name='$p_name',seriese='$se',selling_price='$s_pri',s_quantity='$s_qty',discount='$dis',cgst='$cg',sgst='$sg',total_amount='$t_amt',paidamt='$pa',remamt='$ra',peymetho='$pm',customer_name='$nm',mobile='$mob',address='$nadd',bill_date='$bd',bill_no='$bn' where bid=$ed ")or die("qf for update invoice ");
header("location:view_invoice.php");
    }
	else
	{
	//simple invoice update query
mysqli_query($cc,"update invoice_tbl set cat_name='$cnm',company_name='$p_name',seriese='$se',selling_price='$s_pri',s_quantity='$s_qty',discount='$dis',cgst='$cg',sgst='$sg',total_amount='$t_amt',paidamt='$pa',remamt='$ra',peymetho='$pm',customer_name='$nm',mobile='$mob',address='$nadd',bill_date='$bd',bill_no='$bn' where bid=$ed ")or die("qf for update invoice ");
     header("location:view_invoice.php");
}
}
}
?><!DOCTYPE html>
<head>
<link rel="stylesheet" href="button.css"> 
<title>title here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php require_once("header.php"); ?>
<!--header end-->
<!--sidebar start-->
<?php require_once("sidebar.php"); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		                <!-- market-------------------------------------------------------- -->	
		<!-- //market-->
		<div class="row">
			<div class="panel-body">
				<div class="col-md-12 w3ls-graph">
					<!--agileinfo-grap-->
						<div class="agileinfo-grap">
							<div class="agileits-box">
								<header class="agileits-box-header clearfix">
								
								
									<h3>Edit Profile</h3>
									
									
									
								</header>
							<!--	//chartcode---------------------------------------------------------- -->
							
							
							
							
							<form id="form1" name="form1" method="post" action="">
      <table width="50%" border="1" align="center">
        <tr>
          <td colspan="3"><div align="center">Edit Invoice </div></td>
        </tr>
        <tr>
          <td>Type of Item</td>
          <td>:</td>
          <td><input name="cnm" type="text" id="cnm" value="<?php echo $data['cat_name']; ?>"  /></td>
        </tr>
        <tr>
          <td>Compny Name </td>
          <td>:</td>
          <td><input name="p_name" type="text" id="p_name" value="<?php echo $data['company_name']; ?>"  /></td>
        </tr>
        <tr>
          <td>Serese Name </td>
          <td>:</td>
          <td><input name="se" type="text" id="se" value="<?php echo $data['seriese']; ?>" /></td>
        </tr>
        <tr>
          <td>Selling Price</td>
          <td>:</td>
          <td><input name="s_pri" type="text" id="s_pri" placeholder="Enter Selling Price" value="<?php echo $data['selling_price']; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)" /></td>
        </tr>
        <tr>
          <td>Selling Qty </td>
          <td>:</td>
          <td><input name="s_qty" type="text" id="s_qty"  placeholder="Enter Selling Quntity" value="<?php echo "$o_sqty"; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)"  />
            &nbsp; Present Stock=<?php echo "$ppoqty"; ?></td>
        </tr>
        <tr>
          <td>Descount(%)</td>
          <td>:</td>
          <td><input name="dis" type="text" id="dis"  placeholder="Enter Descount" value="<?php echo $data['discount']; ?>"   onKeyPress="return (event.charCode > 47 && event.charCode < 58)"  /></td>
        </tr>
        <tr>
          <td>CGST(%)</td>
          <td>:</td>
          <td><input name="cg" type="text" id="cg" placeholder="Enter CGST" value="<?php echo $data['cgst']; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)"   /></td>
        </tr>
        <tr>
          <td>SGST(%)</td>
          <td>:</td>
          <td><input name="sg" type="text" id="sg"  placeholder="Enter SGST" onBlur="return f2();" value="<?php echo $data['sgst']; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)"  /></td>
        </tr>
        <tr>
          <td>Total Amount </td>
          <td>:</td>
          <td><input name="t_amt" type="text" id="t_amt" size="25"  placeholder="Show Total Amount Automaticaly" readonly="readonly" value="<?php echo $data['total_amount']; ?>"   /></td>
        </tr>
        <tr>
          <td>Paid Amount </td>
          <td>:</td>
          <td><input name="pa" type="text" id="pa" onBlur="return f3();" placeholder="Paid Amount" value="<?php echo $data['paidamt']; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)"  /></td>
        </tr>
        <tr>
          <td>Remaining Amount </td>
          <td>:</td>
          <td><input name="ra" type="text" id="ra" size="29" placeholder="Show Remaining Amount Automaticaly"  value="<?php echo $data['remamt']; ?>"  /></td>
        </tr>
        <tr>
          <td>Pay Method </td>
          <td>:</td>
          <td><select name="pm" id="pm">
              <option value="Cash" <?php if($data['peymetho']=="Cash"){?> selected="selected" <?php } ?> >Cash</option>
              <option value="Atm" <?php if($data['peymetho']=="Atm"){?> selected="selected" <?php } ?>>Atm</option>
              <option value="Online" <?php if($data['peymetho']=="Online"){?> selected="selected" <?php } ?>>Online</option>
              <option value="Upi" <?php if($data['peymetho']=="Upi"){?> selected="selected" <?php } ?>>Upi</option>
              <option value="-" <?php if($data['peymetho']=="-"){?> selected="selected" <?php } ?>>Other</option>
            </select>          </td>
        </tr>
        <tr>
          <td>Customer Name </td>
          <td>:</td>
          <td><input name="nm" type="text" id="nm" placeholder="Enter Customer Name" value="<?php echo $data['customer_name']; ?>" onKeyPress="return (event.charCode > 64 && 
	event.charCode < 91) || (event.charCode > 96 && event.charCode < 123 || event.charCode==32)" /></td>
        </tr>
        <tr>
          <td>Mobile No </td>
          <td>:</td>
          <td><input name="mob" type="text" id="mob"  placeholder="Enter Customer Mobile No" maxlength="10" pattern="[6-9]{1}[0-9]{9}" onKeyPress="return (event.charCode &gt; 48 &amp;&amp; 
	event.charCode &lt; 58)" value="<?php echo $data['mobile']; ?>" /></td>
        </tr>
        <tr>
          <td>Cutomer Address </td>
          <td>:</td>
          <td><textarea name="add" id="add" placeholder="Enter Customer Address"><?php echo $data['address']; ?></textarea></td>
        </tr>
        <tr>
          <td>Bill Date </td>
          <td>:</td>
          <td><div>
            <input type="text" name="bd" id="bd" class="tcal" value="<?php echo $data['bill_date']; ?>"  />
          </div></td>
        </tr>
        <tr>
          <td>Bill No </td>
          <td>:</td>
          <td><input name="bn" type="text" id="bn" placeholder="Auto Generat Bill Nomber" value="<?php echo $data['bill_no']; ?>"  onKeyPress="return (event.charCode > 47 && event.charCode < 58)"   /></td>
        </tr>
        <tr>
          <td><div align="center">
            
			<button class="button" type="reset" name="Reset" value="Reset">Reset
			  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
          </div></td>
          <td>&nbsp;</td>
          <td><div align="center">
            
			<button class="button" type="submit" name="Submit" value="Update" onClick="return f1();">Update
  <svg fill="currentColor" viewBox="0 0 24 24" class="icon">
    <path clip-rule="evenodd" fill-rule="evenodd"></path>
  </svg>
</button>
          </div></td>
        </tr>
      </table>
        </form>
							
							
							
							
							
								
							</div>
						</div>
	<!--//agileinfo-grap-->

				</div>
			</div>
		</div>
		<div class="agil-info-calendar">
		<!-- calendar -->
		
		<!-- //calendar -->
		<!-- //notification------------------------------------------------------- -->
				<!--notification end-->
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
			<!-- tasks -->
			<!-- //reportdailymonthyear------------------------------------------------------------------- -->
		<!-- //tasks -->
	<!--	//chartok----------------------------------------------- -->
 <!-- footer -->
		<?php require_once("footer.php"); ?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->	
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
<script>

function f1()
{
	if(form1.s_pri.value=="")
	{	
		alert("Please Enter Selling Prise..");
		form1.s_pri.focus();
		return false;
	}	
	else if(form1.s_qty.value=="")
	{	
		alert("Please Enter Selling Qyentety..");
		form1.s_qty.focus();
		return false;
	}	
	else if(form1.dis.value=="")
	{	
		alert("Please Enter Descout..");
		form1.dis.focus();
		return false;
	}	
	else if(form1.cg.value=="")
	{	
		alert("Please Enter CGST..");
		form1.cg.focus();
		return false;
	}	
	else if(form1.sg.value=="")
	{	
		alert("Please Enter SGST..");
		form1.sg.focus();
		return false;
	}	
	else if(form1.t_amt.value=="")
	{	
		alert("Please Enter Total Amount..");
		form1.t_amt.focus();
		return false;
	}	
	else if(form1.pa.value=="")
	{	
		alert("Please Enter Paid Amount..");
		form1.pa.focus();
		return false;
	}	
	else if(form1.ra.value=="")
	{	
		alert("Please Enter Remaining Amount..");
		form1.ra.focus();
		return false;
	}	else if(form1.pm.value=="Select Method")
	{	
		alert("Please Select Pay Method..");
		form1.pm.focus();
		return false;
	}	
	else if(form1.nm.value=="")
	{	
		alert("Please Enter Customer Name..");
		form1.nm.focus();
		return false;
	}	
	else if(form1.mob.value=="")
	{	
		alert("Please Enter Mobile Nomber..");
		form1.mob.focus();
		return false;
	}	
	else if(form1.add.value=="")
	{	
		alert("Please Enter Customer Address..");
		form1.add.focus();
		return false;
	}
	else if(form1.bd.value=="")
	{	
		alert("Please Enter Bill Date..");
		form1.bd.focus();
		return false;
	}	
	else if(form1.bn.value=="")
	{	
		alert("Please Enter Bill Nomber..");
		form1.bn.focus();
		return false;
		
	}
	return confirm("are you sure update this Bill detail???");
			
}

function f2()
{

//string to int convert
	var sp=Number(form1.s_pri.value);
	var qt=Number(form1.s_qty.value);
	var de=Number(form1.dis.value);
	var cgs=Number(form1.cg.value);
	var sgs=Number(form1.sg.value);
//seling prise*qty count
	var nt=sp*qt;
//per(%) to Rup convert
	var der=(nt*de)/100;
	var cgsr=(nt*cgs)/100;
	var sgsr=(nt*sgs)/100;
//calculation
	var tm=(nt+cgsr+sgsr)-der;
	
	//for point after show two values
	t_amt.innerHTML= tm.toFixed(2);
	
//value pass
 form1.t_amt.value=tm;	
}
function f3()
{
	var tamt=Number(form1.t_amt.value);
	var pamt=Number(form1.pa.value);
	//remainig amount calculation
	var r_a=(tamt-pamt);
	//for point after show two values
	ra.innerHTML= r_a.toFixed(2);
	//value passing in shtml
	form1.ra.value=r_a;
}
</script>
<?php
if(isset($_REQUEST['msg'])=="nostock")
{
?>
<script>
alert("stock not Available !!!");

</script>
<?php 
}
?>

