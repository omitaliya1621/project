

<li><form name="ok" method="post" action="view_invoice.php"><input type="text" class="form-control search" placeholder="Search BillNo" name="finde" id="finde" onKeyPress="return (event.charCode > 47 && 
	event.charCode < 58 ) || (event.charCode > 12 && 
	event.charCode < 14)" ></form></li>

