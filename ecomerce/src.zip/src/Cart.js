import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

function Cart() {
const {id}=useParams()
const [qty,setqty]=useState(1)
const [data,setdata]=useState({})
useEffect(
  ()=>{
    fetch("http://localhost:5000/products/"+id)
    .then((res)=>res.json())
    .then((data)=>{setdata(data)})
  },[]
  
)
fetch('http://localhost:5000/addcart', {
  method: 'post',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(data)
})


// let a=data.price
// console.log(a)
  return (
    <>
    <div>
      
      {/* Begin Header Bottom Area */}
      <div className="header-bottom mb-0 header-sticky stick d-none d-lg-block d-xl-block">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              {/* Begin Header Bottom Menu Area */}
              <div className="hb-menu">
                <nav>
                  <ul>
                    <li className="dropdown-holder"><a href="index.html">Home</a>
                      <ul className="hb-dropdown">
                        <li><a href="index.html">Home One</a></li>
                        <li><a href="index-2.html">Home Two</a></li>
                        <li><a href="index-3.html">Home Three</a></li>
                        <li><a href="index-4.html">Home Four</a></li>
                      </ul>
                    </li>
                    <li className="catmenu-dropdown megamenu-holder"><a href="shop-left-sidebar.html">Shop</a>
                      <ul className="megamenu hb-megamenu">
                        <li><a href="shop-left-sidebar.html">Shop Page Layout</a>
                          <ul>
                            <li><a href="shop-3-column.html">Shop 3 Column</a></li>
                            <li><a href="shop-4-column.html">Shop 4 Column</a></li>
                            <li><a href="shop-left-sidebar.html">Shop Left Sidebar</a></li>
                            <li><a href="shop-right-sidebar.html">Shop Right Sidebar</a></li>
                            <li><a href="shop-list.html">Shop List</a></li>
                            <li><a href="shop-list-left-sidebar.html">Shop List Left Sidebar</a></li>
                            <li><a href="shop-list-right-sidebar.html">Shop List Right Sidebar</a></li>
                          </ul>
                        </li>
                        <li><a href="single-product-gallery-left.html">Single Product Style</a>
                          <ul>
                            <li><a href="single-product-carousel.html">Single Product Carousel</a></li>
                            <li><a href="single-product-gallery-left.html">Single Product Gallery Left</a></li>
                            <li><a href="single-product-gallery-right.html">Single Product Gallery Right</a></li>
                            <li><a href="single-product-tab-style-top.html">Single Product Tab Style Top</a></li>
                            <li><a href="single-product-tab-style-left.html">Single Product Tab Style Left</a></li>
                            <li><a href="single-product-tab-style-right.html">Single Product Tab Style Right</a></li>
                          </ul>
                        </li>
                        <li><a href="single-product.html">Single Products</a>
                          <ul>
                            <li><a href="single-product.html">Single Product</a></li>
                            <li><a href="single-product-sale.html">Single Product Sale</a></li>
                            <li><a href="single-product-group.html">Single Product Group</a></li>
                            <li><a href="single-product-normal.html">Single Product Normal</a></li>
                            <li><a href="single-product-affiliate.html">Single Product Affiliate</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                    <li className="dropdown-holder"><a href="blog-left-sidebar.html">Blog</a>
                      <ul className="hb-dropdown">
                        <li className="sub-dropdown-holder"><a href="blog-left-sidebar.html">Blog Grid View</a>
                          <ul className="hb-dropdown hb-sub-dropdown">
                            <li><a href="blog-2-column.html">Blog 2 Column</a></li>
                            <li><a href="blog-3-column.html">Blog 3 Column</a></li>
                            <li><a href="blog-left-sidebar.html">Grid Left Sidebar</a></li>
                            <li><a href="blog-right-sidebar.html">Grid Right Sidebar</a></li>
                          </ul>
                        </li>
                        <li className="sub-dropdown-holder"><a href="blog-list-left-sidebar.html">Blog List View</a>
                          <ul className="hb-dropdown hb-sub-dropdown">
                            <li><a href="blog-list.html">Blog List</a></li>
                            <li><a href="blog-list-left-sidebar.html">List Left Sidebar</a></li>
                            <li><a href="blog-list-right-sidebar.html">List Right Sidebar</a></li>
                          </ul>
                        </li>
                        <li className="sub-dropdown-holder"><a href="blog-details-left-sidebar.html">Blog Details</a>
                          <ul className="hb-dropdown hb-sub-dropdown">
                            <li><a href="blog-details-left-sidebar.html">Left Sidebar</a></li>
                            <li><a href="blog-details-right-sidebar.html">Right Sidebar</a></li>
                          </ul>
                        </li>
                        <li className="sub-dropdown-holder"><a href="blog-gallery-format.html">Blog Format</a>
                          <ul className="hb-dropdown hb-sub-dropdown">
                            <li><a href="blog-audio-format.html">Blog Audio Format</a></li>
                            <li><a href="blog-video-format.html">Blog Video Format</a></li>
                            <li><a href="blog-gallery-format.html">Blog Gallery Format</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                    <li className="catmenu-dropdown megamenu-static-holder"><a href="index.html">Pages</a>
                      <ul className="megamenu hb-megamenu">
                        <li><a href="blog-left-sidebar.html">Blog Layouts</a>
                          <ul>
                            <li><a href="blog-2-column.html">Blog 2 Column</a></li>
                            <li><a href="blog-3-column.html">Blog 3 Column</a></li>
                            <li><a href="blog-left-sidebar.html">Grid Left Sidebar</a></li>
                            <li><a href="blog-right-sidebar.html">Grid Right Sidebar</a></li>
                            <li><a href="blog-list.html">Blog List</a></li>
                            <li><a href="blog-list-left-sidebar.html">List Left Sidebar</a></li>
                            <li><a href="blog-list-right-sidebar.html">List Right Sidebar</a></li>
                          </ul>
                        </li>
                        <li><a href="blog-details-left-sidebar.html">Blog Details Pages</a>
                          <ul>
                            <li><a href="blog-details-left-sidebar.html">Left Sidebar</a></li>
                            <li><a href="blog-details-right-sidebar.html">Right Sidebar</a></li>
                            <li><a href="blog-audio-format.html">Blog Audio Format</a></li>
                            <li><a href="blog-video-format.html">Blog Video Format</a></li>
                            <li><a href="blog-gallery-format.html">Blog Gallery Format</a></li>
                          </ul>
                        </li>
                        <li><a href="index.html">Other Pages</a>
                          <ul>
                            <li><a href="login-register.html">My Account</a></li>
                            <li><a href="checkout.html">Checkout</a></li>
                            <li><a href="compare.html">Compare</a></li>
                            <li><a href="wishlist.html">Wishlist</a></li>
                            <li className="active"><a href="shopping-cart.html">Shopping Cart</a></li>
                          </ul>
                        </li>
                        <li><a href="index.html">Other Pages 2</a>
                          <ul>
                            <li><a href="contact.html">Contact</a></li>
                            <li><a href="about-us.html">About Us</a></li>
                            <li><a href="faq.html">FAQ</a></li>
                            <li><a href="404.html">404 Error</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                    <li><a href="about-us.html">About Us</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="shop-left-sidebar.html">Smartwatch</a></li>
                    <li><a href="shop-left-sidebar.html">Accessories</a></li>
                  </ul>
                </nav>
              </div>
              {/* Header Bottom Menu Area End Here */}
            </div>
          </div>
        </div>
      </div>
      {/* Header Bottom Area End Here */}
      {/* Begin Mobile Menu Area */}
      <div className="mobile-menu-area d-lg-none d-xl-none col-12">
        <div className="container">
          <div className="row">
            <div className="mobile-menu">
            </div>
          </div>
        </div>
      </div>
      {/* Mobile Menu Area End Here */}
      {/* Header Area End Here */}
      {/* Begin Li's Breadcrumb Area */}
      <div className="breadcrumb-area">
        <div className="container">
          <div className="breadcrumb-content">
            <ul>
              <li><Link to={'/home'}>Home</Link></li>
              <li className="active">Shopping Cart</li>
            </ul>
          </div>
        </div>
      </div>
      {/* Li's Breadcrumb Area End Here */}
      {/*Shopping Cart Area Strat*/}
      <div className="Shopping-cart-area pt-60 pb-60">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <form action="#">
                <div className="table-content table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        <th className="li-product-remove">remove</th>
                        <th className="li-product-thumbnail">images</th>
                        <th className="cart-product-name">Product</th>
                        <th className="li-product-price">Unit Price</th>
                        <th className="li-product-quantity">Quantity</th>
                        <th className="li-product-subtotal">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="li-product-remove"><a href="#"><i className="fa fa-times" /></a></td>
                        <td className="li-product-thumbnail"><a><img src={data.src} alt="khkgkg" width={'100px'} height={'100px'} /></a></td>
                        <td className="li-product-name"><a href="#">{data.name}</a></td>
                        <td className="li-product-price"><span className="amount">{data.price}</span></td>
                        <td className="quantity">
                          <label>Quantity</label>
                          <div className="cart-plus-minus">
                            <input className="cart-plus-minus-box" Value={qty} type="text" />
                            <div className="dec qtybutton" onClick={()=>{if(qty>=1){setqty(qty-1)}}}><i className="fa fa-angle-down"  /></div>
                            <div className="inc qtybutton" onClick={(()=>setqty(qty+1))}><i className="fa fa-angle-up"  /></div>
                          </div>
                        </td>
                        <td className="product-subtotal"><span className="amount">{(data.price)*qty}</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="row">
                  <div className="col-12">
                    <div className="coupon-all">
                      <div className="coupon">
                        <input id="coupon_code" className="input-text" name="coupon_code" defaultValue placeholder="Coupon code" type="text" />
                        <input className="button" name="apply_coupon" defaultValue="Apply coupon" type="submit" />
                      </div>
                      <div className="coupon2">
                        <input className="button" name="update_cart" defaultValue="Update cart" type="submit" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-5 ml-auto">
                    <div className="cart-page-total">
                      <h2>Cart totals</h2>
                      <ul>
                        <li>Subtotal <span>$130.00</span></li>
                        <li>Total <span>$130.00</span></li>
                      </ul>
                      <a href="#">Proceed to checkout</a>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/*Shopping Cart Area End*/}
    </div>
    </>
  )
}

export default Cart