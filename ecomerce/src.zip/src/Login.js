import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Bounce, toast, ToastContainer } from 'react-toastify'

export default function Login() {
    const [Email, setEmail] = useState('')
    const [Password, setPassword] = useState('')
    const [data, setdata] = useState([])
    const navigate = useNavigate()
    // const [Password, setPassword] = useState('')
    const submit = (e) => {
        e.preventDefault()
        fetch('http://localhost:5000/register')
            .then((res) => res.json())
            .then((data) => { setdata(data) })

       // Check if user exists
       const user = data.find((v) => v.Email === Email && v.Password === Password);

       if (user) {
           toast.success("Login successful!", {
               position: "top-center",
               autoClose: 1000,
               theme: "light",
               transition: Bounce,
           });

           setTimeout(() => navigate('/home'), 2000);
       } else {
           toast.error("Invalid email or password!", {
               position: "top-center",
               autoClose: 1500,
               theme: "light",
               transition: Bounce,
                   });
    }}
    return (
        <div className="container vh-100 d-flex align-items-center">
            <div className="row justify-content-center align-items-center">
                {/* Left Section */}
                <ToastContainer />
                <div className="col-lg-6 text-center text-lg-start mb-4 mb-lg-0">
                    <h1 className="fw-bold text-primary display-3">E-commerce</h1>
                    <p className="fs-4">E-commerce helps you connect and share with the people in your life.</p>
                </div>
                {/* Right Section */}
                <div className="col-lg-5">
                    <div className="bg-white p-4 rounded shadow-sm">
                        <form onSubmit={submit}>
                            <input onChange={(e) => setEmail(e.target.value)} type="text" className="form-control mb-3" placeholder="Email address or phone number" />
                            <input onChange={(e) => setPassword(e.target.value)} type="password" className="form-control mb-3" placeholder="Password" />
                            <input type='submit' className="btn btn-primary w-100 mb-3" value="Log in"></input>
                        </form>
                        <a href="#" className="d-block text-center text-decoration-none text-primary mb-3">Forgotten password?</a>
                        <hr />
                        <Link to='/register' className="btn btn-success w-100">Create new account</Link>
                    </div>
                    <p className="mt-4 text-center">
                        <a href="#" className="fw-bold text-dark text-decoration-none">Create a Page</a> for a celebrity, brand, or business.
                    </p>
                </div>
            </div>
        </div>

    )
}
