import React from 'react'
import Header from './Header'
import Footer from './Footer'
import Product from './Product'
import Cart from './Cart'

export default  function Home() {
    return (
        <>
        <div className="body-wrapper">
            <Product/>
           

        </div>
        
        </>
    )
}
