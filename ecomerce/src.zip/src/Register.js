import React, { useEffect, useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { Bounce, toast, ToastContainer } from 'react-toastify'

function Register() {
    const [Email, setEmail] = useState('')
    const [Password, setPassword] = useState('')
    const [data, setdata] = useState([])
    const [confirm, setconfirm] = useState({})
    const navigate = useNavigate()

    const submit = (async (e) => {
        e.preventDefault();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
        if (!Email || !Password) {
            toast.error("Please fill in all fields!", {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                theme: "light",
                transition: Bounce,
            });
        } else {
            // Fetch data first
            const res = await fetch('http://localhost:5000/register');
            const data = await res.json();
    
            // Check if email exists in the data
            const emailExists = data.some((user) => user.Email === Email);
            
            if (emailExists) {
                toast.error('Email alerady exist', {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: false,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "colored",
                    transition: Bounce,
                    });
                
            } else {
                if (emailRegex.test(Email)) {
                    let obj = { Email, Password };
                    await fetch('http://localhost:5000/register', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(obj)
                    });
                    navigate("/"); // Navigate to another page after successful registration
                } else {
                    toast.error("Please enter a valid email", {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: false,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "colored",
                        transition: Bounce,
                        });
                }
            }
    
            // Reset email and password after successful submission
            setEmail('');
            setPassword('');
        }
    });

    return (
        <div className="container vh-100 d-flex align-items-center">
            <div className="row justify-content-center align-items-center">
                {/* Left Section */}

                <ToastContainer />
                <div className="col-lg-6 text-center text-lg-start mb-4 mb-lg-0">
                    <h1 className="fw-bold text-primary display-3">E-commerce</h1>
                    <p className="fs-4">E-commerce helps you connect and share with the people in your life.</p>
                </div>
                {/* Right Section */}
                <div className="col-lg-5">
                    <div className="bg-white p-4 rounded shadow-sm">
                        <form onSubmit={submit}>
                            <input value={Email} onChange={(e) => { setEmail(e.target.value) }} type="text" className="form-control mb-3" placeholder="Email address or phone number" />
                            <input value={Password} onChange={(e) => { setPassword(e.target.value) }} type="password" className="form-control mb-3" placeholder="Password" />
                            <input type="submit" value="Log in" className="btn btn-primary w-100 mb-3"></input>
                        </form>
                        <hr />
                        <Link to='/' className="btn btn-success w-100">Already have an account?</Link>
                    </div>
                    <p className="mt-4 text-center">
                        <a href="#" className="fw-bold text-dark text-decoration-none">Create a Page</a> for a celebrity, brand, or business.
                    </p>
                </div>
            </div>
        </div>
    )
}

export default Register